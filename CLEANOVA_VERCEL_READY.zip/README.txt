CLEANOVA — VERCEL VERSION

Baca README_VERCEL.txt untuk langkah deployment ke Vercel.
Paket ini menggunakan PHP community runtime dan membutuhkan database MySQL eksternal.
Jangan mengunggah file ZIP sebagai subfolder; ekstrak lalu upload seluruh isi folder ini ke root repository GitHub.
