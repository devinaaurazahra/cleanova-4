<?php
declare(strict_types=1);

// Front controller for the Vercel PHP community runtime.
// Existing application pages remain in their original folders.
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = rawurldecode($path);

$routes = [
    '/' => __DIR__ . '/../index.php',
    '/index.php' => __DIR__ . '/../index.php',
    '/order.php' => __DIR__ . '/../order.php',
    '/admin' => __DIR__ . '/../admin/login.php',
    '/admin/' => __DIR__ . '/../admin/login.php',
    '/admin/login.php' => __DIR__ . '/../admin/login.php',
    '/admin/dashboard.php' => __DIR__ . '/../admin/dashboard.php',
    '/admin/logout.php' => __DIR__ . '/../admin/logout.php',
];

if (!isset($routes[$path])) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Halaman tidak ditemukan.';
    exit;
}

require $routes[$path];
