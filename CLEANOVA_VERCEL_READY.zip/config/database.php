<?php
declare(strict_types=1);

// Set these values in Vercel > Project > Settings > Environment Variables.
$host = getenv('DB_HOST') ?: '';
$db = getenv('DB_NAME') ?: '';
$user = getenv('DB_USER') ?: '';
$pass = getenv('DB_PASS') ?: '';
$port = getenv('DB_PORT') ?: '3306';
$charset = 'utf8mb4';

if ($host === '' || $db === '' || $user === '') {
    http_response_code(500);
    exit('Konfigurasi database belum lengkap. Atur DB_HOST, DB_NAME, DB_USER, dan DB_PASS di Vercel.');
}

$dsn = "mysql:host={$host};port={$port};dbname={$db};charset={$charset}";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    error_log('CLEANOVA database connection failed: ' . $e->getMessage());
    http_response_code(500);
    exit('Koneksi database gagal. Periksa Environment Variables dan akses database dari Vercel.');
}
