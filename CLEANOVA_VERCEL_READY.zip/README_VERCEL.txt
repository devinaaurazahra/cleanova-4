CLEANOVA — VERCEL DEPLOYMENT PACKAGE
====================================

PENTING
- Paket ini disesuaikan agar halaman PHP dijalankan melalui community PHP runtime di Vercel.
- Runtime PHP tersebut dikelola komunitas, bukan runtime resmi Vercel.
- Vercel tidak menyediakan database MySQL. CLEANOVA harus memakai MySQL eksternal yang mengizinkan koneksi dari Vercel.
- Jangan masukkan password database ke dalam file PHP atau GitHub. Gunakan Environment Variables di Vercel.

ISI PAKET
- Halaman pelanggan: index.php dan order.php
- Admin: admin/login.php, admin/dashboard.php, admin/logout.php
- Database schema: database/cleanova.sql
- Vercel entry point: api/index.php
- Vercel config: vercel.json

LANGKAH DEPLOY
1. Siapkan database MySQL eksternal yang dapat diakses dari internet/Vercel.
2. Buat database kosong pada provider MySQL tersebut.
3. Import file database/cleanova.sql ke database yang sudah dibuat.
4. Upload seluruh isi ZIP ini ke repository GitHub baru. Pastikan vercel.json berada di root repository, bukan di dalam subfolder tambahan.
5. Di Vercel pilih Add New > Project, lalu Import repository GitHub tersebut.
6. Framework Preset pilih Other. Build Command dan Output Directory dikosongkan jika Vercel meminta pengaturan manual.
7. Setelah project dibuat, buka Settings > Environment Variables. Tambahkan:
   DB_HOST = host MySQL dari provider database
   DB_PORT = 3306 (atau port yang diberikan provider)
   DB_NAME = nama database
   DB_USER = username database
   DB_PASS = password database
8. Terapkan Environment Variables untuk Production (dan Preview jika diperlukan), lalu lakukan Redeploy.
9. Buka URL Vercel. Halaman admin berada di /admin/login.php.

LOGIN ADMIN AWAL
Username: admin
Password: cleanova123
Segera ganti password setelah login. Jangan bagikan kredensial ini.

CATATAN DATABASE
- Database harus mengizinkan koneksi remote dari aplikasi Vercel. Jika provider mewajibkan IP allowlist, ikuti kebijakan provider; alamat IP function Vercel dapat berubah.
- Pilih provider database yang memang mendukung koneksi serverless/remote dan SSL bila diwajibkan.
- Vercel Function memiliki filesystem sementara; jangan menyimpan data pesanan atau file penting ke filesystem lokal.

CATATAN SESSION ADMIN
- Sesi PHP disimpan di /tmp. Penyimpanan sementara pada serverless dapat tidak bertahan saat function berpindah instance atau restart. Untuk pemakaian produksi, autentikasi sebaiknya dipindahkan ke session store terpusat.

TROUBLESHOOTING
- 404: pastikan vercel.json berada di root repository dan deployment terbaru sudah berhasil.
- Error konfigurasi database: periksa semua Environment Variables, lalu Redeploy.
- Connection refused/timeout: database belum mengizinkan koneksi dari Vercel atau host/port salah.
- Build error runtime: runtime vercel-php adalah community runtime; cek build log dan dokumentasi runtime.
