<?php ini_set('session.save_path', '/tmp');
session_start(); $_SESSION=[]; session_destroy(); header('Location: login.php'); exit;