<?php
declare(strict_types=1);
ini_set('session.save_path', '/tmp');
session_start();
require __DIR__ . '/../config/database.php';
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
$statuses=['Pesanan Baru','Dikonfirmasi','Dijemput','Diproses','Siap Diantar','Selesai','Dibatalkan'];
$notice=''; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id=(int)($_POST['order_id']??0); $action=$_POST['action']??'';
  if($id>0 && $action==='accept'){
    $q=$pdo->prepare("UPDATE orders SET status='Dikonfirmasi',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='Pesanan Baru'"); $q->execute([$id]);
    $notice=$q->rowCount()?'Pesanan berhasil diterima dan dikonfirmasi.':'Pesanan sudah diproses atau tidak ditemukan.';
  } elseif($id>0 && $action==='cancel'){
    $q=$pdo->prepare("UPDATE orders SET status='Dibatalkan',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status IN ('Pesanan Baru','Dikonfirmasi')"); $q->execute([$id]);
    $notice=$q->rowCount()?'Pesanan dibatalkan.':'Pesanan tidak dapat dibatalkan.';
  } elseif($id>0 && $action==='status' && in_array($_POST['status']??'', $statuses, true)){
    $q=$pdo->prepare('UPDATE orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?'); $q->execute([$_POST['status'],$id]); $notice='Status pesanan diperbarui.';
  }
}
$new=(int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status='Pesanan Baru'")->fetchColumn();
$total=(int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$process=(int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('Dikonfirmasi','Dijemput','Diproses','Siap Diantar')")->fetchColumn();
$done=(int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status='Selesai'")->fetchColumn();
$orders=$pdo->query("SELECT o.*,s.name service_name FROM orders o JOIN services s ON s.id=o.service_id ORDER BY CASE WHEN o.status='Pesanan Baru' THEN 0 ELSE 1 END,o.created_at DESC LIMIT 50")->fetchAll();
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard Admin - CLEANOVA</title><link rel="stylesheet" href="../assets/css/style.css"></head><body class="admin-page">
<header class="navbar"><div class="container nav-inner"><a class="brand" href="../index.php">CLEANOVA <span class="admin-tag">ADMIN</span></a><div>Halo, <?=h($_SESSION['admin_name']??'Admin')?> · <a href="logout.php">Keluar</a></div></div></header>
<main class="section"><div class="container"><div class="dashboard-head"><div><span class="eyebrow">DASHBOARD</span><h1>Kelola Pesanan</h1><p>Pesanan baru muncul paling atas agar dapat segera diterima.</p></div><?php if($new):?><div class="new-badge">🔔 <?=$new?> Pesanan Baru</div><?php endif;?></div>
<?php if($notice):?><div class="alert success"><?=h($notice)?></div><?php endif;?>
<div class="stats"><div class="stat"><span>Pesanan Baru</span><b><?=$new?></b></div><div class="stat"><span>Total Pesanan</span><b><?=$total?></b></div><div class="stat"><span>Sedang Diproses</span><b><?=$process?></b></div><div class="stat"><span>Selesai</span><b><?=$done?></b></div></div>
<div class="panel"><div class="panel-head"><h2>Daftar Pesanan</h2><span>50 terbaru</span></div><div class="table-wrap"><table><thead><tr><th>Kode</th><th>Pelanggan</th><th>Layanan</th><th>Berat</th><th>Status</th><th>Waktu</th><th>Aksi</th></tr></thead><tbody>
<?php if(!$orders):?><tr><td colspan="7" class="empty">Belum ada pesanan.</td></tr><?php endif;?>
<?php foreach($orders as $o):?><tr class="<?= $o['status']==='Pesanan Baru'?'row-new':''?>"><td><b><?=h($o['order_code'])?></b></td><td><?=h($o['customer_name'])?><br><small><?=h($o['whatsapp'])?></small></td><td><?=h($o['service_name'])?></td><td><?=h(number_format((float)$o['weight'],1,',','.'))?> kg</td><td><span class="status"><?=h($o['status'])?></span></td><td><?=h(date('d/m/Y H:i',strtotime($o['created_at'])))?></td><td class="actions"><?php if($o['status']==='Pesanan Baru'):?><form method="post"><input type="hidden" name="order_id" value="<?=$o['id']?>"><input type="hidden" name="action" value="accept"><button class="btn btn-small" type="submit">✓ Terima Pesanan</button></form><form method="post"><input type="hidden" name="order_id" value="<?=$o['id']?>"><input type="hidden" name="action" value="cancel"><button class="btn btn-small btn-danger" type="submit">Tolak</button></form><?php elseif(!in_array($o['status'],['Selesai','Dibatalkan'],true)):?><form method="post" class="status-form"><input type="hidden" name="order_id" value="<?=$o['id']?>"><input type="hidden" name="action" value="status"><select name="status" onchange="this.form.submit()"><?php foreach($statuses as $st):?><option value="<?=h($st)?>" <?=$st===$o['status']?'selected':''?>><?=h($st)?></option><?php endforeach;?></select></form><?php else:?><span class="muted">Selesai</span><?php endif;?></td></tr><?php endforeach;?></tbody></table></div></div></div></main></body></html>