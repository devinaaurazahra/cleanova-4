<?php
ini_set('session.save_path', '/tmp');
session_start();
require_once __DIR__ . '/../config/database.php';
if(isset($_SESSION['admin_id'])){header('Location: dashboard.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $username=trim($_POST['username']??''); $password=$_POST['password']??'';
 $stmt=$pdo->prepare("SELECT * FROM admins WHERE username=? LIMIT 1"); $stmt->execute([$username]); $admin=$stmt->fetch();
 if($admin && password_verify($password,$admin['password_hash'])){
   session_regenerate_id(true); $_SESSION['admin_id']=$admin['id']; $_SESSION['admin_name']=$admin['name']; header('Location: dashboard.php'); exit;
 }
 $error='Username atau password salah.';
}
?><!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login — CLEANOVA</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><main class="form-page"><div class="container narrow"><div class="success-card" style="text-align:left"><a class="brand" href="../index.php"><span>✦</span> CLEANOVA</a><div class="form-intro" style="text-align:left;margin-top:45px"><span class="eyebrow">ADMINISTRATOR</span><h1>Masuk</h1><p>Kelola pesanan CLEANOVA.</p></div><?php if($error): ?><div class="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?><form method="post"><label>Username<input name="username" required autocomplete="username"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><button class="btn primary full">Masuk ke Dashboard</button></form></div></div></main></body></html>