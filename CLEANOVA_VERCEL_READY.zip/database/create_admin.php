<?php
require_once __DIR__.'/../config/database.php';
$hash=password_hash('cleanova123', PASSWORD_DEFAULT);
$pdo->exec("CREATE TABLE IF NOT EXISTS admins (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 username VARCHAR(50) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB");
$stmt=$pdo->prepare("INSERT INTO admins(name,username,password_hash) VALUES(?,?,?) ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash),name=VALUES(name)");
$stmt->execute(['Administrator','admin',$hash]);
echo 'Admin berhasil dibuat. Username: admin | Password: cleanova123. Hapus file database/create_admin.php setelah berhasil.';
